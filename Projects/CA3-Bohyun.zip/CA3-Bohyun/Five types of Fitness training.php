<html>
    <head>
        <title>Flexibility Training</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="Flexibility-style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="Five types of fitness training.html">Flexibility Training</a>
                    <ul>
                        <li><a href="Dynamic.php">Dynamic Strength-training</a></li>
                        <li><a href="Static.php">Static Strength-training</a></li>
                        <li><a href="Aerobic.php">Aerobic Training</a></li>
                        <li><a href="Circuit.php">Circuit Training</a></li>

                    </ul>
                </li>
                <li><a href="About us.php">About us</a></li>
                <li><a href="Contact us.php">Contact us</a></li>
            </ul>
        </nav>
        <div>
            <main>
                <p>
                    Five major types of fitness training include flexibility exercise, dynamic strength-training, static strength-training, aerobic exercise and circuit training. 
                    A solid workout plan will incorporate all five of these major fitness training types to improve your health.
                </p>
                <section>
                    <h1>Flexibility Training</h1>
                </section>
                <p class="main">
                    Flexibility training is among the most important types of fitness training because it provides a foundation for all your other exercise types.
                    These stretching exercises reduce your risk of injury, improve your flexibility and range of motion, and serve as a solid warm-up for more vigorous exercise. 
                    Additionally, yoga can strengthen and relax your muscles, while tai chi can reduce stress and improve your balance. 
                    Flexibility exercises are an excellent way to improve your posture and breathing.   

                </p>
                <ul style="list-style-type:circle">
                    <li style="font-size:200%">The importance and purpose of flexibility Can-Fit-Pro</li>
                    <p>Flexibility is needed to perform everyday activities with relative ease. 
                        To get out of bed, lift children, or sweep the floor, we need flexibility. 
                        Flexibility tends to deteriorate with age, often due to a sedentary lifestyle. 
                        Without adequate flexibility, daily activities become more difficult to perform.
                        Over time, we create body movements and posture habits that can lead to reduced mobility of joints and compromised body positions. 
                        Staying active and stretching regularly help prevent this loss of mobility, which ensures independence as we age. 
                        Being flexible significantly reduces the chance of experiencing occasional and chronic back pain.
                    </p>
                    <li style="font-size:200%">Purpose of Flexibility Training</li>
                    <p>It is important to include flexibility training as part of your clients’ regular fitness routines. 
                        Improved flexibility may enhance performance in aerobic training and muscular conditioning as well as in sport. 
                        There is scientific evidence that the incidence of injury decreases when people include flexibility training in their routines due to the enhanced ability to move unimpeded through a wider ROM.
                        The only exception to this would be when there is an excessive or unstable ROM, which may increase the likelihood of injury.
                        When used appropriately, flexibility training allows clients to become more in tune with their body. It is a form of active relaxation that can improve both mental and physical recovery.
                        Once the workout is complete, clients can focus on relaxation and rejuvenation of mind and body. After pushing the body to work hard, it is time to encourage recovery. 
                        This is an excellent time for flexibility training because the muscles are warm and pliable, allowing them to stretch farther.
                        Following are some of the major benefits of flexibility training:
                    <ol style="list-style-type: upper-roman" >
                        <li style="font-size:200%"> Reduces stress in the exercising muscles and releases tension developed during the workout.</li>
                        <li style="font-size:200%">Assists with posture by balancing the tension placed across the joint by the muscles that cross it. Proper posture minimizes stress and maximizes the strength of all joint movements</li>
                        <li style="font-size:200%">Reduces the risk of injury during exercise and daily activities because muscles are more pliable.</li>
                        <li style="font-size:200%">Improves performance of everyday activities as well as performance in exercise and sport.</li>
                    </ol>
                    </p>
                    <li style="font-size:200%">Intensity of Flexibility Training</li>
                    <p>
                        Stretching should never be painful. The focus should be on bringing the muscle to a point of slight tension. 
                        Encourage clients to continue their breathing pattern throughout the stretch.
                    </p>
                    <li style="font-size:200%">Duration of Flexibility Training</li>
                    <p>
                        The length of the flexibility component depends on the needs and motivation of the client. In most cases, flexibility training should last at least 5 to 10 minutes. 
                        Stretching is one area of the workout that tends to get cut short when time is running out. Don’t assume that clients will perform their own recovery and flexibility once their session with you has ended. 
                        Being organized with workout design ensures that there is always time for stretching.
                    </p>
                </ul>

            </main>
        </div>
    </body>
</html>
