

<html>
    <head>
        <meta charset="UTF-8" />

        <meta name="viewport" content="width-device-width,initial-scale=1.0" />

        <title>
            Research from Local Storage
        </title>

        <style type="text/css">
            label {display: inline-block; width: 150px}
        </style>

        <script src="getLSdata.js" type="text/javascript"></script>
    </head>

    <body onload="getLocalStorage()">
        <h1>Cartoon</h1>

        <form name="LSdata" id="LSdata" action="readLocalStorage.php">
            <label>Name: </label><input name="name" id="name" readonly /><br>
            <label>Address </label><input name="address" id="address" readonly /><br>							
            <label>Age: </label><input name="age" id="age" readonly /><br>	
            <label>Type: </label><input name="type" id="type" readonly /><br>	
            <label>Email: </label><input name="email" id="email" readonly /><br>
            <label>Mobile: </label><input name="mobile" id="mobile" readonly /><br>
            Comment:<textarea  id="comment" name="comment" readonly/></textarea><br>	
        <label>Rating: </label><input name="rate" id="rate" readonly /><br>
        <label>Date: </label><input name="date" id="date" readonly /><br>


    </form>
</body>
</html>
