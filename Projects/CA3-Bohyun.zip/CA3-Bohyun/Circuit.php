<html>
    <head>
        <title>Circuit</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="Circuit-style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="Five types of fitness training.php">Flexibility Training</a>
                    <ul>
                        <li><a href="Dynamic.php">Dynamic Strength-training</a></li>
                        <li><a href="Static.php">Static Strength-training</a></li>
                        <li><a href="Aerobic.php">Aerobic Training</a></li>
                        <li><a href="Circuit.php">Circuit Training</a></li>
                   
            </ul>
        </li>
        <li><a href="About us.php">About us</a></li>
        <li><a href="Contact us.php">Contact us</a></li>
    </ul>
</nav>
<div>
    <main>
        <section>
            <h1>Circuit Training</h1>
        </section>
        <p>
            Circuit training combines strength-training with aerobic exercise. This type of exercise involves jogging between exercise stations. At individual stations, you perform different flexibility, dynamic strength training and static strength training exercises. 
            By jogging between the stations, you maintain an elevated heart rate throughout the duration of the circuit. Typically, you perform each station for 30 to 60 seconds and continue the overall circuit for 30 to 60 minutes.
            This is an effective option to break-up the monotony of your usual workout routine and can be performed indoors during poor weather. To save on space indoors, you can simply run in place for 30 to 60 seconds between exercises.
        </p>
        <section>
            <h2>How to Build the Perfect Circuit Workout?</h2>
        </section>
        <p>
            Imagine a turbocharged workout routine that mixes cardio and strength training and has you in and out of the gym in 30 minutes. Plus, it's infinitely and easily customized to help you reach your goals faster. 
            Sound too good to be true? It's not! It's called circuit training.

            While this style of training has a lot to recommend it, figuring out how to set up an effective circuit workout can be intimidating at first. 
            That's why we pulled together six easy steps to help you build your perfect circuit.
        </p>
        <section>
            <h3>Step 1: Select your time limit</h3>
        </section>
        <p>
            Circuit training is simply a workout based around a set number of "stations" that you repeat until your time runs out. So knowing how much time you have can help you determine how many circuits you'll need to complete and how hard you'll need to work. 
            (The shorter the workout, the harder you should be pushing!) Anywhere from 10-45 minutes is ideal.
        </p>
        <section>
            <h4>Step 2: Pick an upper-body exercise</h4>
        </section>
        <p>
            The trick with circuit training is to use whatever you have handy. If you're at the gym, you have a wide range of options, but all you really need is your body. You can choose a different upper-body move each time through the circuit or simply repeat the same exercise every time if you want to keep things simple.
        </p>
        <section>
            <h5>Step 3:  Pick a lower-body exercise</h5>
        </section>
        <p>
            Just like you did with the upper body, choose exercises that will work each part of your lower body. You can change up the moves each time through the circuit or keep them the same.
        </p>
        <section>
            <h6>Step 4: Pick a compound exercise</h6>
        </section>
        <p>
            Weight training is an excellent workout, but you'll really get your heartrate up by adding in some total-body movements.
        </p>
        <section>
            <h7>Step 5: Choose a sprint for 1 minute</h7>
        </section>
        <p>
            Research shows that short, fast sprints are the most effective way to torch fat—especially around your midsection. Pick any type of cardio you like and go all out for 1 minute.
        </p>
    </main>
</div>
</body>
</html>
