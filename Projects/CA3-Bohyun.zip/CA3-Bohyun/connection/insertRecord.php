<?php

require_once 'Connections/CA3-Bohyun.php';
if (isset($_POST['Name']) !== Null)
{
    $Name = $_POST['Name'];
}
else
{
    $Name = $_POST['No Entered Name'];
}
if (isset($_POST['Address']) !== Null)
{
    $Address = $_POST['Address'];
}
else
{
    $Address = $_POST['No address entered'];
}
if (isset($_POST['Age']) !== Null)
{
    $Age = $_POST['Age'];
}
else
{
    $Age = $_POST['No age entered'];
}
if (isset($_POST['Email']) !== Null)
{
    $Email = $_POST['Email'];
}
else
{
    $Email = $_POST['No Entered Email'];
}
if (isset($_POST['Mobile']) !== Null)
{
    $Mobile = $_POST['Mobile'];
}
else
{
    $Mobile = $_POST['No Entered Mobile'];
}
if (isset($_POST['Date']) !== Null)
{
    $Date = $_POST['Date'];
}
else
{
    $Date = $_POST['No Entered Date'];
}
if (isset($_POST['Comment']) !== Null)
{
    $Comment = $_POST['Comment'];
}
else
{
    $Comment = $_POST['No Entered Comment'];
}
