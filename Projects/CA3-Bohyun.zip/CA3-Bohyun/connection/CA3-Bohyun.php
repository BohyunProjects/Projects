<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "cartoon";
$link = mysqli_connect($host, $user, $password, $database) or die("error connecting to DB" . mysqli_errno($link));

$query = "SELECT * FROM cartoon";

$result = mysqli_query($link, $query);
?>

