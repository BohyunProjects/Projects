/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function getLocalStorage()
{
    document.LSdata.name.value = localStorage.fullName;
    document.LSdata.address.value = localStorage.address;
    document.LSdata.age.value = localStorage.age;
    document.LSdata.type.value = localStorage.typeName;
    document.LSdata.email.value = localStorage.emailAddress;
    document.LSdata.rate.value = localStorage.rating;
    document.LSdata.mobile.value = localStorage.mobile;
    document.LSdata.comment.value = localStorage.comment;
    document.LSdata.date.value = localStorage.date;

}

