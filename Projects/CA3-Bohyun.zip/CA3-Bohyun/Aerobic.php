<html>
    <head>
        <title>Aerobic Training</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="Aerobic-style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <nav>
            <nav>
                <ul>
                    <li><a href="home.php">Home</a></li>
                    <li><a href="Five types of fitness training.php">Flexibility Training</a>
                        <ul>
                            <li><a href="Dynamic.php">Dynamic Strength-training</a></li>
                            <li><a href="Static.php">Static Strength-training</a> </li>
                            <li><a href="Aerobic.php">Aerobic Training</a></li>
                            <li><a href="Circuit.php">Circuit Training</a></li>
                        
                </ul>
                </li>
                <li><a href="About us.php">About us</a></li>
                <li><a href="Contact us.php">Contact us</a></li>
                </ul>
            </nav>
        </nav>
        <div>
            <main>
                <section>
                    <h1 style="font-size:200%;font-family:impact;color:hotpink;font-style:oblique">Aerobic Training</h1>
                </section>
                <p>
                    Aerobic training strengthens your cardiovascular system by increasing your heart rate and breathing. These exercises use large muscle groups to perform rhythmic actions for a sustained period of time.
                    Typically, they are performed for longer than 15 minutes and should maintain your heart rate at between 60 percent to 80 percent of your maximum heart rate. 
                    Examples of aerobic exercise include fast walking, jogging, running, stair steppers, elliptical and swimming.
                </p>
                <section>
                    <h2>What is the Best Type of Aerobic Exercise?</h2>
                </section>
                <p>
                <section>
                    <h3>Your aerobic exercise program should have four goals:</h3>
                </section>
                <li style="font-size:150%;font-family:Tahoma;color:gold">It is aerobic. It uses large muscle groups repetitively for a sustained amount of time</li>
                <li style="font-size:150%;font-family:Tahoma;color:gold">You perform it for 30 to 60 minutes, three to five days a week</li>
                <li style="font-size:150%;font-family:Tahoma;color:gold">It meets the cardiovascular goals your doctor or exercise physiologist has prescribed for you</li>
                <li style="font-size:150%;font-family:Tahoma;color:gold">It is something you will enjoy doing for an extended period of time</li>
                </p>
                <section>
                    <h4>Safety First!</h4>
                </section>
                <p>
                    The type of exercise you choose is a personal decision, but you should take certain factors into consideration to reduce the risk of injury or complications and make exercise more enjoyable.
                <li style="font-size:150%;font-family:Tahoma;color:gold">Always speak to your doctor first before starting any new exercise program</li>
                <li style="font-size:150%;font-family:Tahoma;color:gold">Chose a type of exercise you are more likely to stay with over the long-term</li>
                <li style="font-size:150%;font-family:Tahoma;color:gold">Perform your activity at a level in which you can carry on a conversation or speak clearly while exercising</li>
                </p>
                <section>
                    <h5>Benefits of aerobic exercise</h5>
                </section>
                <p>
                <ul>
                    <li style="font-size:150%;font-family:Tahoma;color:gold">Improves cardiovascular conditioning</li>
                    <li style="font-size:150%;font-family:Tahoma;color:gold">Decreases risk of heart disease</li>
                    <li style="font-size:150%;font-family:Tahoma;color:gold">Lowers blood pressure</li>
                    <li style="font-size:150%;font-family:Tahoma;color:gold">Increases HDL or "good" cholesterol</li>
                    <li style="font-size:150%;font-family:Tahoma;color:gold">Helps to better control blood sugar</li>
                    <li style="font-size:150%;font-family:Tahoma;color:gold">Assists in weight management and/or weight loss</li>
                    <li style="font-size:150%;font-family:Tahoma;color:gold">Improves lung function</li>
                    <li style="font-size:150%;font-family:Tahoma;color:gold">Decreases resting heart rate</li>
                </ul>
                </p>
                <section>
                    <h6>How often and for how long should I do these exercises?</h6>
                </section>
                <p>
                    The American Heart Association recommends that everyone reach a minimum of 30 minutes of some form of cardiovascular exercise 5 to 7 days per week. This can be broken up into 10-minute time periods.
                    This means that taking three walks of 10 minutes each would let you reach the recommended minimum guideline for reducing the risk of heart disease, diabetes, hypertension, and high cholesterol. 
                    You would also burn the same number of calories as you would if you walked for the full 30 minutes at one time.

                    The American College of Sports Medicine recommends a minimum of three sessions of 30 minutes of the total should be made up of moderate to vigorous exercise to improve cardio-respiratory fitness and help manage weight.

                    It is appropriate to do aerobic exercise every day. There is no need to rest in between sessions unless you are at an extreme level of training, such as preparing for a marathon, or if you experience reoccurring joint pain. 
                    If joint pain is a limiting factor, it would be appropriate to alternate less painful exercises with those that may cause joint pain or to discontinue the painful exercise altogether.
                </p>
            </main>
        </div>
    </body>
</html>

