﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=397704
// To debug code on page load in Ripple or on Android devices/emulators: launch your app, set breakpoints, 
// and then run "window.location.reload()" in the JavaScript Console.
var currentUserId;
var curBalance;
var user;
(function () {
    "use strict";
    var amount;
    document.addEventListener('deviceready', onDeviceReady.bind(this), false);

    function onDeviceReady() {
        // Handle the Cordova pause and resume events
        document.addEventListener('pause', onPause.bind(this), false);
        document.addEventListener('resume', onResume.bind(this), false);

        // TODO: Cordova has been loaded. Perform any initialization that requires Cordova here.
        amount = document.location.search.substr(document.location.search.indexOf("=") + 1);
        user = window.localStorage.getItem("currentUser");
        var db = openDatabase('seQRDatabase', '1.0', 'seQRDatabase', '2*1024*1024');
        db.transaction(function (tx) {
            tx.executeSql('SELECT userid FROM USERS WHERE email =\"' + user + '\"', [], function (tx, results) {
                var len = results.rows.length, i;
                for (i = 0; i < len; i++) {
                    currentUserId = results.rows.item(i).userid;
                }

               
                tx.executeSql('SELECT balance FROM USERS WHERE userid=\"' + currentUserId + '\"', [], function (tx, results) {
                    var length = results.rows.length, i;
                    for (i = 0; i < length; i++) {
                        curBalance = results.rows.item(i).balance;
                    }
                });
            });
        });
        navigator.notification.alert("You account balance is €" + curBalance);

    };



    function onPause() {
        // TODO: This application has been suspended. Save application state here.
    };

    function onResume() {
        // TODO: This application has been reactivated. Restore application state here.
    };


})();

