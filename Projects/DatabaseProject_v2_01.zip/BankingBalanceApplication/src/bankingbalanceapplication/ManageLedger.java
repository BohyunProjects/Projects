/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingbalanceapplication;

import static bankingbalanceapplication.MainApp.conn;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author LmThu
 */
public class ManageLedger {

    public void manageLedger()
    {
        System.out.println("UNDER DEVELOPMENT");
    }
    private void insert_ledger() {
        String new_legder= ViewMainApp.getUserInput("Please Enter the new Company");
        
    }
}
