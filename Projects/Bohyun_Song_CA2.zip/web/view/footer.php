<footer>
    <p class="copyright">
        &copy; <?php echo date("Y"); ?> My Holiday Memory, Inc.
    </p>
</footer>
    </body>
</html>
