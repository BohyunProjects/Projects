<?php include './view/header.php'; ?>
<main>
	<section>
		<h1><?php echo $holidays_id; ?></h1>
		<div>
			<p><b>Description:</b>$<?php echo $description; ?></p>
			<p><b>Date_Start:</b>$<?php echo $date_start; ?></p>
			<p><b>Date_End:</b>$<?php echo $date_end; ?></p>
			<p><b>Destination:</b>$<?php echo $destination; ?></p>
			<p><b>Cost:</b>$<?php echo $cost; ?></p>
			<form action="<?php echo '../cart'?>" method="post">
				<input type="hidden" name="action" value="add">
				<input type="hidden" name="holidays_id" value="1" size="2">
				<br><br>
				<input type="submit" value="Add to Cart">
			</form> 
		</div>
	</section>
</main>
<?php include './view/footer.php'; ?>
