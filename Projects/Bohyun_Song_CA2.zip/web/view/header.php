<html>
    <head>
        <meta charset="UTF-8">
        <title>My Holiday Memory</title>
    </head>
    <body>
        <header><h1>My Holiday Memory</h1></header>

