Template.city.helpers(
 {
 	activities: function() {
 		return Activities.find({nature: "place"});
 	}
 });