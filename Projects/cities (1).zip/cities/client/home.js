 Template.home.helpers(
 {
 	cities: function() {
		//console.log(Cities.find({}));
 		return Cities.find({});
 	}
 });

Template.home.events({	
	'submit form' : function(event){
		event.preventDefault();
		console.log(event.target.name.value);
		Cities.insert({
			name:event.target.name.value,
			lat:event.target.latitude.value,
			long:event.target.longitude.value
		})
	}

});
