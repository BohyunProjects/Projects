Cities = new Mongo.Collection("cities");
Activities = new Mongo.Collection("activities");
// For the predefined collection users, you need to use Meteor.users