Hello, this is my web project. My project name is Find, which is about travling around world. You can leave your good memory in here.
My web application includes 9 webpage views: Home, Explored, Map,Rating, Image,User,Login, Logout, SignUp. Every functions all connect to the database and their tables.
And I have 8 multi-tables in my database; the implement relevant database crud operations on webpages using SQL and PHP.
I designed this web application with MVC structure.

Home page: this page has an dynamic menu. It is the first step to use this web application. If your are not the user of this application,u only can look through the exist content in this application,such like Map User, also you can leave us a message.the aim to do this, is to protect my application security, i wanna have good stakeholders for my application. In order word, if you really have interest in my app,you can sign up to be a member of us. 

Sign Up: in this form, you should leave your name, email address,password. We will show you if you already registered,the notice is under the form. If you registered successful, you can user your email and password to login. In the moment, we insert your details into our database,it is safety that only the manager can delete your detail.

Login page just have a form for users inputing their email and password. When the user login, will take them to the explored page.
What will you do when you wanna leave this application? Don't worry, in the menu, click Join Us you will find "LogOut". The user only needs to clike that button, then they will safe and success logout, go back to the home page.

The register, login and logout are eassy,  unfortunately I tried to use the MVC structure to do these funcions. But I failed, beacause it influenced my rating MVC structure. I still use the "session" ,PDO and Prepared Statments in both three functions. I separated users to Administrator and normal User.

Explored page is the main page. When you walk in this page, the traveling gallery will appear in your eyes. The photos in gallery are upload by the exist users, and they also did some simple description for these photos. These photos were took in their tourism as their memory. The other users can appreciate these beautiful photos. If the users have some comments about one of these pictures, they can click this picture then the comments form will pop out with that picture. Ask users to input their name and leave comments, afther these steps click the "Post comment"button. Meanwhile, the user comments will show below the form, we can know who left the comment and the published time and date.
The hard part of Explored for me is the comments, i did this Explored function with MVC structure. But in comment part, i used a little javascript to control, the code cost me hours to finish and fix the errors.

I have a survice for users, the Map. I created this Map function with Goodle Map API which i studied in France. It is powerful function, only you input the country or cities, then the map will give you the Lat,Lng back. If you input the address more detailedness, the map even can show you the street and surrounding buildings. You can do many options in this map, zoom in/out, drag and drop the marker to the correct location. The map has two different, one is normal map, another one is Satelite.
This part is interesting,and it is not difficult.

The rating function is the administators post some comments in the application, users can depend their own habbit to choose like or dislike. One user can rate once for each comment, however they can reset their choices. This function has JSON ,Ajax and javascript DOM in the MVC structure. The JSON and Ajax are too difficult to me, so i asked my dad for help,because what i code,there had too many errors.Some of them, i don't know how to fix. After this project, i knew a little bit JSON. 

How the users to upload their photos? Now, i am going to my Image page. When you click the Image buttom, it brings you to view page. Over there it is a table, the items of this table are : FileName, FileType FileSize and View. Becareful, i mean the "File". That means you ont only can upload pictures but also can upload any files, like PDF,DOC,EXE,VIDEO,MP3,ZIP,etc. Is this interesting you?
You will find the blue words "upload new files", click it. The page will turn to the image page, there has two bars called Browse and upload, Brose provides you to select the file you wanna upload, upload just mean upload. If you didn't select any file, but also click the upload, now an error textbox will pop. After you finished uploading, you wanna see it. You should click the link under bars, go back to the view page. Click the end of each row "view file",a little while, a new windows tab will show your picture. 
In this function, i just use the SOL, PHP and jQuery in MVC structure.

Every exist users in my application will check from a table, called User page. In the page, users can filled the form by themselves or the designer will filled form for users. The table needs users First Name, Last Name, Tech(means where did you go or where you plan to go),Email and Address. This table can change their details anytime or delete, also can add new people.
This part is difficult, i wanted to make it more poweful so i choosed to use ajax. I did this for days, in this processing, i met too many problems. I looked the info online and books, right i asked help from my dad. Whatever it takes, as a result it works.

The last one is Contact Us. This function seems like simple, just ask to leave a message for us, of course it is optional. The textarea allows users to write something they want me to improve or their feeling. Everything in the textarea, after click the "Add record" button, will show me above the textarea. Not designers can see also the other users. In case of the user wanna change their text or delete, I created a delete mark on the right of each text bar. Hence, click the delete mark, your text will disappear above the textarea. 
This function for me it is difficult either. Because i use the Ajax and JSON with Javascript DOM to make that happen. Even got to know these since last two pages, but still have a large numbers errors. 

My web application maybe not so well. But which makes me feel better, it is i tried to use everything i learned from the class in my application. I can fix  part of errors by myself, but still need to prove, i cost too much time on some problems.

In the end, i hope you will like this. Thanks million.
Bohyun