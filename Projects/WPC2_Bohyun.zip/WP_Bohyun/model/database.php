<?php

$dsn = 'mysql:host=localhost;dbname=wp_db';
$username = 'wp_db';
$password = 'wp_db';

try{
    $db = new PDO($dsn,$username,$password);
} catch (PDOException $e){
    $error_message = $e->getMessage();
    //include('./errors/database_error.php');
    exit();
}



 //$name = mysql_real_escape_string($_POST["author"]);
 //$comment = mysql_real_escape_string($_POST["comment"]);
 
 //mysql_query("INSERT INTO comments VALUES(' $name ',' $comment ')");
?>

