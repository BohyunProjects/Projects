/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingbalanceapplication;

import static bankingbalanceapplication.MainApp.conn;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author LmThu
 */
public class ManageTransaction {
    public void browseTransaction() {
//        Statement stmt=null;
//        try {
//            stmt = conn.createStatement();
//            String sql = "SELECT * FROM debit_transaction_record";
//            ResultSet rs = stmt.executeQuery(sql);
//            while (rs.next()) {
//                System.out.println(rs.getString("description"));
//            }
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//        }
        System.out.println("UNDER DEVELOPMENT");
    }
}
