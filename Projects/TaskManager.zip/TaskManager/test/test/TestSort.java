/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import taskmanager.Task;
import taskmanager.TaskList;

/**
 *
 * @author LmThu
 */
public class TestSort {

    TaskList t;

    public TestSort() {

    }

    @Before
    public void setUp() {
        t = new TaskList();
        t.addNewTask(new Task());
        t.addNewTask(new Task());
        t.addNewTask(new Task());
    }

    @After
    public void tearDown() {
        t=null;
    }

    @Test
    public static void testSort()
    {
        fail("not yet Implemented");
    }
}
