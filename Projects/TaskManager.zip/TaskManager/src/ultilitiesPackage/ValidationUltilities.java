/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ultilitiesPackage;

import java.util.Calendar;

/**
 *
 * @author LmThu
 */
public class ValidationUltilities {
    public static boolean isNumeric(String st) {
        try {
            double temp = Double.parseDouble(st);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    
   
    
}
