/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ultilitiesPackage;

/**
 *
 * @author LmThu
 */
public class YesNoMenu extends Menu {

    public YesNoMenu(String name, String desString) {
        super(name,"No, go back",desString);
        super.addOption("Yes");
        super.addOption("Wait And check");
    }

}
